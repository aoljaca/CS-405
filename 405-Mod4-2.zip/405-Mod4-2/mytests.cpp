#include <gtest/gtest.h>
#include <vector>
#include <ctime>

class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    void SetUp() override
    {
        // initialize random seed
        srand(time(nullptr));
    }

    void TearDown() override {}
};

class CollectionTest : public ::testing::Test
{
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count)
    {
        assert(count >= 0); // Change the assertion to allow count = 0
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// Test that the collection pointer is not null after setup
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that the collection is empty when created
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Comment this test out to prevent the test from running
// Uncomment this test to see a failure in the test explorer
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// Test adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());

    // Add one entry
    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

// Test adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Add five entries
    add_entries(5);

    ASSERT_EQ(collection->size(), 5);
}

// Test that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize)
{
    // Add different numbers of entries and check the max size
    add_entries(0);
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(1);
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(5);
    ASSERT_GE(collection->max_size(), collection->size());

    add_entries(10);
    ASSERT_GE(collection->max_size(), collection->size());
}

// Test that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize)
{
    // Add different numbers of entries and check the capacity
    add_entries(0);
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(1);
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());

    add_entries(10);
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test that resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesCollection)
{
    // Add some entries first
    add_entries(5);
    size_t oldSize = collection->size();

    // Resize the collection to a larger size
    collection->resize(10);

    // Check that the size has increased
    ASSERT_GT(collection->size(), oldSize);
    ASSERT_EQ(collection->size(), 10);
}

// Test that resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesCollection)
{
    // Add some entries first
    add_entries(10);
    size_t oldSize = collection->size();

    // Resize the collection to a smaller size
    collection->resize(5);

    // Check that the size has decreased
    ASSERT_LT(collection->size(), oldSize);
    ASSERT_EQ(collection->size(), 5);
}

// Test that resizing decreases the collection to zero
TEST_F(CollectionTest, ResizingToZero)
{
    // Add some entries first
    add_entries(10);

    // Resize the collection to zero
    collection->resize(0);

    // Check that the collection is empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test that clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Add some entries first
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    // Clear the collection
    collection->clear();

    // Check that the collection is empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test that erase(begin, end) erases the collection
TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
    // Add some entries first
    add_entries(10);
    ASSERT_EQ(collection->size(), 10);

    // Erase the entire collection
    collection->erase(collection->begin(), collection->end());

    // Check that the collection is empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test that reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    // Add some entries first
    add_entries(5);
    size_t oldSize = collection->size();
    size_t oldCapacity = collection->capacity();

    // Reserve more space for the collection
    collection->reserve(20);

    // Check that the size remains the same
    ASSERT_EQ(collection->size(), oldSize);

    // Check that the capacity has increased
    ASSERT_GT(collection->capacity(), oldCapacity);
}

// Test that the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRangeExceptionIsThrown)
{
    // Add some entries first
    add_entries(5);

    // Try to access an index that is out of range
    ASSERT_THROW(collection->at(10), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// You can add your own custom test cases here

// Test adding multiple values to the collection
TEST_F(CollectionTest, CanAddMultipleValuesToVector) {
    // Add 5 random entries
    add_entries(5);
    
    // Check that the collection is not empty
    ASSERT_FALSE(collection->empty());

    // Check that the size is as expected
    ASSERT_EQ(collection->size(), 5);

    // Check that all added values are within the valid range (0-99)
    for (const auto& value : *collection) {
        ASSERT_GE(value, 0);
        ASSERT_LT(value, 100);
    }
}

// Test that the collection is empty after clearing
TEST_F(CollectionTest, ClearEmptiesCollection) {
    // Add some random entries first
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    // Clear the collection
    collection->clear();

    // Check that the collection is empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test case main function
int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    // Add the custom environment to set up random seed
    ::testing::AddGlobalTestEnvironment(new Environment());
    return RUN_ALL_TESTS();
}
