#include <iostream>
#include <exception>
#include <typeinfo>

class CustomException : public std::exception
{
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    throw std::runtime_error("A standard exception was thrown.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception &ex)
    {
        // Catch and differentiate the custom exception and standard exceptions based on their types
        if (typeid(ex) == typeid(CustomException))
        {
            std::cout << "CustomException caught: " << ex.what() << std::endl;
        }
        else
        {
            std::cout << "Standard exception caught: " << ex.what() << std::endl;
        }
    }

    // TODO: Throw a custom exception derived from std::exception
    // and catch it explicitly in main
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) // Remove noexcept from here
{
    // TODO: Throw an exception to deal with divide by zero errors using
    // a standard C++ defined exception
    if (den == 0)
    {
        throw std::runtime_error("Division by zero error.");
    }
    return (num / den);
}

void do_division()
{
    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception &ex)
    {
        std::cout << "Exception caught in do_division(): " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException &)
    {
        std::cout << "Uncaught CustomException." << std::endl;
    }
    catch (const std::exception &ex)
    {
        std::cout << "Uncaught standard exception: " << ex.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Unknown exception caught." << std::endl;
    }

    return 0;
}
